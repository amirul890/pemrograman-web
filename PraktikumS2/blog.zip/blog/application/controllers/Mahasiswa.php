<?php
class Mahasiswa extends CI_Controller{
    // membbuat method index
    public function index(){
        // akses model mahasiswa
        $this->load->model('mahasiswa_model');
        $mahasiswa = $this->mahasiswa_model->getAll();
        $data['mahasiswa'] = $mahasiswa;

        $this->load->view('layouts/header');
        $this->load->view('mahasiswa/index', $data);
        $this->load->view('layouts/footer');
    }     
    public function detail($id){
        // akses model mahasiswa
        $this->load->model('mahasiswa_model');
        $siswa = $this->mahasiswa_model->getById($id);
        $data['siswa'] = $siswa;
        $this->load->view('layouts/header');
        $this->load->view('mahasiswa/detail', $data);
        $this->load->view('layouts/footer');
    }
    // // Method Dosen
    // public function dosen(){
    //     $this->load->model('dosen_model','ds1');
    //     // buat objek dosen1
    //     $this->ds1->nidn='011';
    //     $this->ds1->pendidikan='S1';

    //     $this->load->model('dosen_model','ds2');
    //     // buat objek dosen2
    //     $this->ds2->nidn='012';
    //     $this->ds2->pendidikan='S2';

    //     $this->load->model('dosen_model','ds3');
    //     // buat objek dosen1
    //     $this->ds3->nidn='013';
    //     $this->ds3->pendidikan='S3';

    //     $list_ds = [$this->ds1, $this->ds2, $this->ds3];
    //     $data2['list_ds'] = $list_ds;
    //     $this->load->view('mahasiswa/dosen', $data2);
    // }
    
    // Method Matakuliah
    // public function matakuliah(){
    //     $this->load->model('dosen_model', 'mk1');
    //     // buat objek matakuliah1
    //     $this->mk1->nama='Pemweb';
    //     $this->mk1->sks='3';
    //     $this->mk1->kode='PW2';

    //     $list_mk = [$this->mk1];
    //     $data3['list_mk'] = $list_mk;
    //     $this->load->view('mahasiswa/matakuliah', $data3);
    // }
}
?>